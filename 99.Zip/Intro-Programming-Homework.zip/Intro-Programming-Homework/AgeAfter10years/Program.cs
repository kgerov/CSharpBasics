﻿using System;


class Program
{
    static void Main()
    {
        int a;
        Console.WriteLine("Input age:" );
        a=int.Parse(Console.ReadLine());
        Console.WriteLine(a+10);

    }
}
