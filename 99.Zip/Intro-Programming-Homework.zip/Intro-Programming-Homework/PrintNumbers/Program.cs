﻿using System;

class Program
{
    static void Main()
    {
        Console.WriteLine("1\n101\n1001");
    }
}