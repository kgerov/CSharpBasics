﻿using System;

class Program
{
    static void Main()
    {
        int n = 0xFE;
        Console.WriteLine(n);
    }
}
