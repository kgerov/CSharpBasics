﻿using System;

    class Program
    {
        static void Main()
        {
            string FName = "Batko";
            string LName = "Toshko";
            byte Age = 45;
            char Gender = 'm';
            ulong ID = 8306112507;
            ulong EmNumber = 275600043427569999;
            Console.WriteLine("First and Last name are: {0} {1}", FName, LName);
            Console.WriteLine("The age is {0} and the gender is {1}", Age, Gender);
            Console.WriteLine("The Personal ID number is {0} and the Employee Number is  {1}", ID, EmNumber);
        }
    }
