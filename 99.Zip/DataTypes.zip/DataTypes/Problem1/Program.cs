﻿using System;

class Program
{
    static void Main()
    {
        ushort n1 = 52130;
        sbyte n2 = -115;
        long n3 = 4825932;
        byte n4 = 98;
        short n5 = -10000;
        Console.WriteLine("{0}, {1}, {2}, {3}, {4}", n1, n2, n3, n4, n5);
    }
}

