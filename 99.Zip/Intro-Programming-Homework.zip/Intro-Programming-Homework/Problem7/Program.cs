﻿using System;

class Program
{
    static void Main()
    {
        Console.WriteLine("Konstantin");
        Console.WriteLine("Gerov");
    }
}